import org.junit.After;
import org.junit.Before;
import org.junit.runner.RunWith;
import org.junit.runners.Suite;
import org.junit.runners.Suite.SuiteClasses;

@RunWith(Suite.class)
@SuiteClasses({ TestBoardPanel.class, TestClock.class, TestTetris.class})
public class AllTests {
//	public static Scanner scan = new Scanner(System.in);
//	private Robot rob;
	
//	@Before
//	public void setUp() throws Exception{
////		rob = new Robot();
//	}
//	
//	@After
//	public void tearDown() throws Exception{
////		rob = null;
//		//scan.close();
//	}
}
